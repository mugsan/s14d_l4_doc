//
//  BombuModel.cpp
//  Bombomanu_client
//
//  Created by Magnus Björk on 03/11/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#include "BombuModel.h"
/**
 *  Model of any bomb placed on the gamefield
 *  @param ownerid  id of player who dropped the bomb
 *  @param bombid   id of the placed bomb
 *  @param str      strength of placed bomb
 *  @param pos      position of placed bomb
 */
BombuModel::BombuModel(int ownerid, int bombid,int str,Coordinate pos){
    
    this->lastTime = time(0);
    this->ownerid  = ownerid;
    this->bombid   = bombid;
    this->timer    = 5;
    this->str      = str;
    this->pos      = pos;
    
    this->isDetonated = false;
    printf("\t[placed a bomb with bombid: %d]\n",this->bombid);
}
/**
 *  Update timer of this bomb, bomb should last 5s only
 *
 *  @return true if 5s has passed or bomb is set to detonate by other bombs
 */
bool BombuModel::update(void){
    long now = time(0);
    
    this->timer   -= now - this->lastTime;
    this->lastTime = now;
    
    return this->timer <= 0 || this->isDetonated;
}
