//
//  Thread.h
//  s0014d laboration5 server
//
//  Created by Magnus Björk on 20/10/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#ifndef __bombthread
#define __bombthread

#include <stdio.h>
#include <pthread.h>
#include <vector>
#include <algorithm>

#include "Socket.h"
#include "GameModel.h"
#include "MessageFactory.h"

class BombThread{
    pthread_t*              thread;
    pthread_attr_t*         attr;
    bool                    running;
    
    std::vector<Socket*>*   clients;
    GameModel*              model;
    
    static void* run(void* a_thread);
    
public:
    BombThread(std::vector<Socket*>* clients, GameModel* model);
    
    void action();
    void start();
    void stop();
    
};
#endif /* defined(__s0014d_laboration5_server__Thread__) */
