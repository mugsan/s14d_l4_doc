//
//  ServerSocket.cpp
//  s0014d laboration5 server
//
//  Created by Magnus Björk on 19/10/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#include "ServerSocket.h"
/**
 * Initiates a sockets and binds it to host address.
 * Starts listening to port.
 *
 * @param port port to bind to
 */
ServerSocket::ServerSocket(const char* port){
    this->port = port;
    
    struct addrinfo hints, *res;
    
    memset(&hints, 0, sizeof hints);
    hints.ai_family   = AF_UNSPEC;  // use IPv4 or IPv6, whichever
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags    = AI_PASSIVE;     // fill in my IP for me
    
    if ((getaddrinfo(NULL, this->port, &hints, &res)) <0){
        std::cout << "u wot m8?" << std::endl;
    }
    
    // make a socket:
    if((this->sockfd = socket(res->ai_family, res->ai_socktype,res->ai_protocol)) < 0){
        std::cout << "socket error.\n";
    }
    
    // Enable resuseage of socket.
    int yes=1;
    if (setsockopt(this->sockfd,SOL_SOCKET,SO_REUSEADDR,&yes,sizeof(int)) == -1) {
        std::cout << "setsockopt error.\n";
    }
    
    //bind address to socket.
    if (bind(sockfd, res->ai_addr, res->ai_addrlen) < 0) {
        std::cout << "error binding.\n";
    }
    
    //starts listening on socket
    if (listen(this->sockfd, 20) < 0) {
        std::cout << "error listening.\n";
    }
    
    //remove linked list
    freeaddrinfo(res);
}
/**
 *  Accepts incoming traffic
 *
 *  @return Socket file descriptor to the new connection
 */
int ServerSocket::accept(){
    int new_sockfd;
    struct sockaddr_storage inc_addr;
    
    socklen_t addr_size = sizeof inc_addr;
    if ((new_sockfd = ::accept(this->sockfd, (struct sockaddr*)&inc_addr,&addr_size)) < 0){
        fprintf(stderr, "Accept error: %d\n",errno);
        exit(1);
    }
    return new_sockfd;
}
/**
 *  Close socket.
 */
void ServerSocket::close(void){
    ::close(this->sockfd);
}
