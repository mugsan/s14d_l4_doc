//
//  Listener.h
//  Bombomanu_client
//
//  Created by Magnus Björk on 31/10/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Thread.h"
#import "Socket.h"

@class Listener;
@protocol ListenerDelegate <NSObject>

- (void)listener:(Listener *)listener didReceiveMessage:(char *)message withLength:(int)length;

@end

@interface Listener : Thread

@property (nonatomic, weak) id <ListenerDelegate> delegate;

- (instancetype)initWithSocket: (Socket*)socket;

@end
