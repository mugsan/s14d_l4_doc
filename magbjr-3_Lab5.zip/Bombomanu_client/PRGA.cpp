//
//  PRGA.cpp
//  s0014d laboration5 server
//
//  Created by Magnus Björk on 27/10/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#include "PRGA.h"
#include <iostream>

//Constructor includes Key-Scheduling-Algorithm
PRGA::PRGA(const char* key, int key_len){
    this->i = 0;
    this->j = 0;
    this->key_array = new unsigned char[256];
    int i;
    for (i = 0; i < 256; i++){
        this->key_array[i] = i;
    }
    
    int j = 0;
    for (i = 0; i < 256; i++){
        j = (j + this->key_array[i] + key[i % key_len]) % 256;
        std::swap(this->key_array[i], this->key_array[j]);
    }
}

PRGA::~PRGA(){
    delete [] this->key_array;
}

//Pseudo Random Generator Algorithm
unsigned char PRGA::getStream(void){
    
    this->i = (this->i + 1) % 256;
    this->j = (this->j + this->key_array[i]) % 256;
    std::swap(this->key_array[i], this->key_array[j]);
    return this->key_array[(this->key_array[i] + this->key_array[j]) % 256];
    
}