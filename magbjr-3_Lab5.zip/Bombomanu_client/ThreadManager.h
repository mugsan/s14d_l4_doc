//
//  ThreadManager.h
//  Bombomanu_client
//
//  Created by Magnus Björk on 30/10/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>

#import "Transmitter.h"
#import "Listener.h"
#import "Socket.h"

@class ThreadManager;

@protocol ThreadManagerDelegate <NSObject>

- (void)manager:(ThreadManager*) manager playerJoin:(int)id_no atPosition: (CGPoint)pos;
- (void)manager:(ThreadManager*) manager oponentJoin:(int)id_no atPosition: (CGPoint)pos;
- (void)manager:(ThreadManager *)manager oponentDied:(int)id_no;

- (void)manager:(ThreadManager*) manager playerLeft:(int)id_no;
- (void)manager:(ThreadManager*) manager playerDied:(int)id_no;
- (void)manager:(ThreadManager*) manager playerWon:(int)id_no;

- (void)manager:(ThreadManager*) manager player:(int)id_no movedTo:(CGPoint)pos;
- (void)manager:(ThreadManager*) manager bombAt:(CGPoint)pos withId:(int)id;
- (void)manager:(ThreadManager*) manager explodeBombId:(int)id andStr: (int)str;

@end

@interface ThreadManager : NSObject
@property (nonatomic, weak) id <ThreadManagerDelegate> delegate;

- (instancetype)initWithUrl: (NSString*)url andPort: (NSString*)port;

- (void)start;
- (void)stop;

//input

- (void)setDestination:(CGPoint)pos;
- (void)advanceMovement;

- (void)setBomb:(CGPoint)pos;

@end
