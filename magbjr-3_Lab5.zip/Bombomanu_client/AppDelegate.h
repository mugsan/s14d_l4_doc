//
//  AppDelegate.h
//  Bombomanu_client
//
//  Created by Magnus Björk on 30/10/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

