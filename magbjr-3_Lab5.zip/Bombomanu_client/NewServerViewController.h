//
//  NewServerViewController.h
//  s0014d laboration5
//
//  Created by Magnus Björk on 15/10/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//
//  ViewController for Adding a new server.

#import <UIKit/UIKit.h>

@interface NewServerViewController : UIViewController
@property (nonatomic) NSMutableDictionary* item;

@end
