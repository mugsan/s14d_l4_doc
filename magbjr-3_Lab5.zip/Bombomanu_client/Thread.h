//
//  Transmitter.h
//  Bombomanu_client
//
//  Created by Magnus Björk on 31/10/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Thread : NSObject

- (instancetype)init;
- (void)start;
- (void)stop;
- (void)run;

@end
