//
//  NewServerViewController.m
//  s0014d laboration5
//
//  Created by Magnus Björk on 15/10/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#import "NewServerViewController.h"

@interface NewServerViewController()
@property (weak, nonatomic) IBOutlet UITextField *nameField;
@property (weak, nonatomic) IBOutlet UITextField *addressField;
@property (weak, nonatomic) IBOutlet UITextField *portField;

//Buttons:
@property (weak, nonatomic) IBOutlet UIBarButtonItem *doneButton;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *cancelButton;

@end

@implementation NewServerViewController

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if (sender == _doneButton && ![_addressField.text  isEqual: @""] && ![_portField  isEqual: @""]) {
        _item = [NSMutableDictionary dictionary];
        _item[@"name"]    = _nameField.text;
        _item[@"port"]    = _portField.text;
        _item[@"address"] = _addressField.text;
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
