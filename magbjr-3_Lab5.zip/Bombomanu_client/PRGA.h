//
//  PRGA.h
//  s0014d laboration5 server
//
//  Created by Magnus Björk on 27/10/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#ifndef __s0014d_laboration5_server__PRGA__
#define __s0014d_laboration5_server__PRGA__

#include <stdio.h>

class PRGA{
    int i;
    int j;
    unsigned char* key_array;
    
public:
    PRGA(const char* key, int key_len);
    ~PRGA();
    unsigned char getStream();
    
};

#endif /* defined(__s0014d_laboration5_server__PRGA__) */
