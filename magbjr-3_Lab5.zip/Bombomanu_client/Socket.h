//
//  Socket.h
//  
//
//  Created by Magnus Björk on 16/10/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <netdb.h>
#import <sys/socket.h>
#import <sys/types.h>
#import <arpa/inet.h>
#import <stdio.h>
#import <pthread.h>

@interface Socket : NSObject

- (instancetype)initWith:(NSString*)url andPort:(NSString*)port;

- (void)sendMessage:(char*)message withLength:(int) length;
- (void)addMessageToBuffer: (char*)message;

- (int)receiveToBuffer:(char*)buffer ofLength: (int)length;
- (void)sendBuffer;

- (BOOL)bufferEmpty;

@end

