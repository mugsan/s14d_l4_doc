//
//  GameFinished.h
//  Bombomanu_client
//
//  Created by Magnus Björk on 01/11/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>
#import "GameScene.h"

@interface GameFinished : SKNode
- (instancetype)initWithTitle:(NSString *)title andScene:(GameScene*)scene;
@property (nonatomic) SKLabelNode* title;
@property (nonatomic) SKLabelNode* disconnectButton;

@end
