//
//  MsgHead.h
//  s0014d laboration5
//
//  Created by Magnus Björk on 12/10/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#ifndef __s0014d_laboration5__MsgHead__
#define __s0014d_laboration5__MsgHead__

#include <stdio.h>
#include <netdb.h>

// Enums och constants
#define MAXNAMELEN 32


enum ObjectDesc
{
    Human,
    NonHuman,
    Vehicle,
    StaticObject
};
enum ObjectForm
{
    Cube,
    Sphere,
    Pyramid,
    Cone
};
struct Coordinate
{
    int x;
    int y;
};

enum MsgType
{
    Join,   // Client joining game at server
    Leave,  // Client leaving game
    Change, // Data: Server -> Clients
    Event,  // Data: Client -> Server
};

// Player information
struct Player
{
    int** path_array;
    bool isAlive;
    Coordinate pos;
    Coordinate destination;
    unsigned int tot_bombs; // Total of bombs;
    unsigned int cur_bombs; // Bomb to drop;
    unsigned int str_bombs; // Strength of bombs;
    unsigned int id;
};


// Included first in all messages
struct MsgHead
{
    unsigned int length;    // Total length for whole message
    unsigned int seq_no;    // Sequence number
    unsigned int id;        // Client ID or 0;
    MsgType type;           // Type of message
};

// Message type Join (Client -> Server)
struct JoinMsg
{
    MsgHead head;
};

// Message type Leave (Client -> Server)
struct LeaveMsg
{
    MsgHead head;
};

// Messages of type Event (Client -> Server)
//---- BEGIN EVENT
enum EventType
{
    Move,
    Bomb
};

struct EventMsg
{
    MsgHead head; 
    EventType type;
};

struct BombuMsg
{
    EventMsg event;
    Coordinate pos;
};
//---- BEGIN MOVE
enum MoveType
{
    Destination,
    Advance
};
    
struct MoveMsg
{
    EventMsg event;
    MoveType type;
};


struct DestinationMsg
{
    MoveMsg    msg;
    Coordinate pos;
};

struct AdvanceMsg
{
    MoveMsg    msg;
};
//---- END MOVE
//---- END EVENT



// Message type Change (Server -> Client)
enum ChangeType
{
    NewPlayer,
    NewPlayerPosition,
    NewBombPosition,
    Explosion,
    PlayerLeave,
    PlayerDied,
    PlayerStop,
    PlayerWon
};

// Included first in all Change messages
struct ChangeMsg
{
    MsgHead head;
    ChangeType type;
};

// Variations of ChangeMsg
struct NewPlayerMsg
{
    ChangeMsg msg; //Change message header with new client id
    Coordinate pos;
};


struct NewPlayerPositionMsg
{
    ChangeMsg msg; //Change message header
    Coordinate pos; //New object position
};

struct NewBombuPositionMsg
{
    ChangeMsg msg;
    Coordinate pos;
    unsigned int bombid;
};

struct ExplosionMsg
{
    ChangeMsg msg;
    Coordinate pos;
    unsigned int bombid;
    unsigned int str;
};

struct PlayerLeaveMsg
{
    ChangeMsg msg; //Change message header with new client id
};

struct PlayerDiedMsg
{
    ChangeMsg msg;
};

struct PlayerStopMsg
{
    ChangeMsg msg;
};

struct PlayerWonMsg
{
    ChangeMsg msg;
};

//Bomb information
struct Bombu
{
    Coordinate pos;
    unsigned int id;
    unsigned int bombid;
};

#endif /* defined(__s0014d_laboration5__MsgHead__) */
