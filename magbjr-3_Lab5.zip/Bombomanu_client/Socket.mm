//
//  Socket.mm
//
//  Created by Magnus Björk on 16/10/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#import "Socket.h"
#import "EncryptionEngine.h"
#import "MessageStructure.h"


@interface Socket()
/**
 *  Socket file descriptor
 */
@property int sockfd;
/**
 *  Object used to encrypt messages.
 */
@property (nonatomic) EncryptionEngine *encryptionEngine;
/**
 *  Bytebuffer to send msgs in numbers
 */
@property NSMutableData* buffer;
/**
 *  Mutex lock for synchronizing
 */
@property NSLock* lock;
/**
 *  Wether to encrypt messages or not.
 */
@property (nonatomic) BOOL encrypt;

@end

@implementation Socket
/**
 *  Initiates a socket and connects to given url and port
 *
 *  @param url  url to connect to
 *  @param port port number to connect to
 *
 *  @return self
 */
- (instancetype)initWith:(NSString *)url andPort:(NSString *)port
{
    self = [super init];
    if (self) {
        
        _encrypt = YES;
        _lock = [[NSLock alloc]init];
        _buffer = [[NSMutableData alloc] init];
        _encryptionEngine = new EncryptionEngine("key",3);//key and length of key
        const char* cUrl  = [url cStringUsingEncoding:NSUTF8StringEncoding];
        const char* cPort = [port cStringUsingEncoding:NSUTF8StringEncoding];
        
        int status;
        
        struct addrinfo hints;
        struct addrinfo* servinfo;
        
        memset(&hints, 0, sizeof hints);
        
        hints.ai_family   = AF_UNSPEC;
        hints.ai_socktype = SOCK_STREAM;
        hints.ai_flags    = AI_PASSIVE;
        
        
        if ((status = getaddrinfo(cUrl, cPort, &hints, &servinfo))) {
            fprintf(stderr, "Getaddrinfo error: %s\n", gai_strerror(status));
            exit(1);
        }
        
        if ((_sockfd = socket(servinfo->ai_family, servinfo->ai_socktype, servinfo->ai_protocol)) == -1){
            printf("Socket error");
            exit(1);
        }
        
        if ((status = connect(_sockfd, servinfo->ai_addr, servinfo->ai_addrlen)) != 0){
            fprintf(stderr, "Connection error: %s\n", gai_strerror(status));
            exit(1);
        }
        
        freeaddrinfo(servinfo);
    }
    return self;
}

/**
 *  Adds a message to a bytebuffer
 *
 *  @param message begining of bytearray
 */
- (void)addMessageToBuffer: (char*)message
{
    [_lock lock];
    
    MsgHead* m = (MsgHead*)message;
    [_buffer appendBytes:message length:m->length];
    
    [_lock unlock];
}

/**
 *  Send buffer and resets index of buffer
 */
- (void)sendBuffer
{
    [_lock lock];
    
    [self sendMessage:(char*)[_buffer bytes] withLength:(int)[_buffer length]];
    [_buffer setLength:0];
    
    [_lock unlock];
}

/**
 *  Sends given message
 *
 *  @param message begining of bytearray
 *  @param length  length of array
 */
- (void)sendMessage:(char *)message withLength:(int)length
{
    if (_encrypt) _encryptionEngine->encrypt(message, length);
    long bytes = ::send(_sockfd, message, length, 0);
    printf("--> [%d bytes sent]\n",(int)bytes);
}

/**
 *  Receives message to given buffer of given length
 *
 *  @param buffer begining of bytearray
 *  @param length length of array
 *
 *  @return return bytes received -1 on error 0 on broken connection.
 */
- (int)receiveToBuffer:(char*)buffer ofLength:(int)length
{
    int res = (int)::recv(_sockfd, buffer, length, 0);
    if (_encrypt) _encryptionEngine->decrypt(buffer, res);
    printf("\t[Received: %d bytes]\n",res);
    return res;
}

- (BOOL)bufferEmpty
{
    return [_buffer length] == 0;
}
@end
