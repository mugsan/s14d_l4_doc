//
//  Transmitter.m
//  Bombomanu_client
//
//  Created by Magnus Björk on 31/10/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#import "Transmitter.h"
@interface Transmitter()
/**
 *  Socket to send messages from.
 */
@property Socket* socket;
@end

@implementation Transmitter

-(instancetype)initWithSocket:(Socket *)socket
{
    if (self = [super init]) {
        _socket = socket;
    }
    return self;
}

/**
 *  If buffer isn't empty, send buffer to server.
 */
-(void)run
{
    if (![_socket bufferEmpty]) {
        [_socket sendBuffer];
        usleep(256000);
    }
}

@end
