//
//  GameScene.h
//  Bombomanu_client
//

//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface GameScene : SKScene
@property (nonatomic) NSMutableDictionary* serverProperties;

- (void) disconnect;

@end
