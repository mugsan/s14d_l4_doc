//
//  Listener.m
//  Bombomanu_client
//
//  Created by Magnus Björk on 31/10/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#import "Listener.h"

@interface Listener()
/**
 *  Socket to listen for incoming messages.
 */
@property Socket*   socket;
/**
 *  Container for incoming message
 */
@property char*     buffer;

@end

@implementation Listener
- (instancetype)initWithSocket:(Socket *)socket{
    if (self = [super init]) {
        _socket = socket;
        _buffer = new char[1024];
    }
    return self;
}

/**
 *  Calls delegate method when a message is received.
 */
-(void)run
{
    int length = [_socket receiveToBuffer:_buffer ofLength:1024];
    [self.delegate listener:self didReceiveMessage:_buffer withLength:length];
}

@end
