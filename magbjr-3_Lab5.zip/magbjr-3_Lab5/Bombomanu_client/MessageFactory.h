//
//  MessageFactory.h
//  Bombomanu_client
//
//  Created by Magnus Björk on 31/10/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#ifndef __Bombomanu_client__MessageFactory__
#define __Bombomanu_client__MessageFactory__

#include "MessageStructure.h" 
#include "BombuModel.h"
#include <stdio.h>


class MessageFactory{
    static volatile unsigned int seq_no;
public:
    int id_no;
    MessageFactory(int id_no);
    
    //client specific (Except for join message)
    MsgHead     create_head(MsgType type, int size);
    JoinMsg     create_join();
    LeaveMsg    create_leave();
    EventMsg    create_event(EventType type);
    MoveMsg     create_move(MoveType type);
    BombuMsg    create_bomb(Coordinate pos, int bomb_number);
    
    DestinationMsg  create_destination(Coordinate pos);
    AdvanceMsg      create_advance();
    
    //server specific messages
    ChangeMsg               create_change(ChangeType type);
    NewPlayerMsg            create_new_player(Coordinate pos);
    NewPlayerMsg            create_new_player(Player player);
    NewPlayerPositionMsg    create_new_player_position(Coordinate pos);
    NewBombuPositionMsg     create_new_bomb_position(int bombid, Coordinate pos);
    ExplosionMsg            create_explosion(int bombid, int str);
    PlayerLeaveMsg          create_player_leave();
    PlayerDiedMsg           create_player_died(int id);
    PlayerStopMsg           create_player_stop();
    PlayerWonMsg            create_player_won(int id);
    
};

#endif /* defined(__Bombomanu_client__MessageFactory__) */
