//
//  GameFinished.m
//  Bombomanu_client
//
//  Created by Magnus Björk on 01/11/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#import "GameFinished.h"

@implementation GameFinished
/**
 *  GameOver screen. fills the gamescene and overrides touchevents.
 *  Only possible exit is to disconnect or shutdown the app
 *
 *  @param title title to show "you won"/"you lost"
 *  @param scene parent of this node.
 *
 *  @return self
 */
- (instancetype)initWithTitle:(NSString *)title andScene:(GameScene*)scene
{
    if (self = [super init]) {
        self.name = @"gameoverscreen";
        self.userInteractionEnabled = YES;
        CGSize s = scene.size;
        CGPoint c = CGPointMake(s.width / 2, s.height / 2); //center of screen
        
        [self setAlpha:1];
        [self setZPosition:1];
        
        _title = [SKLabelNode labelNodeWithText:title];
        CGPoint ptitle = CGPointMake(c.x, c.y + s.height / 4);
        [_title setFontColor:[UIColor redColor]];
        [_title setPosition:ptitle];
        NSLog(@"center.x: %.f .y: %.f",c.x,c.y);
        
        CGPoint pdc = CGPointMake(c.x, c.y - s.height / 4);
        _disconnectButton = [SKLabelNode labelNodeWithText:@"disconnect"];
        [_disconnectButton setPosition:pdc];
        
        
        //Add buttons and title.
        [self addChild:_title];
        [self addChild:_disconnectButton];
    }
    return self;
}

/**
 *  Disconnect button
 *
 *  @param touches
 *  @param event   
 */
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSLog(@"touched");
    UITouch* touch = [touches anyObject];
    CGPoint p = [touch locationInNode:self];
    if (_disconnectButton == [self nodeAtPoint:p]) {
        //disconnect
        NSLog(@"bye - dc");
        
        GameScene* parent = (GameScene*)[self parent];
        
        [parent disconnect];
        [self removeFromParent];
    }
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    
}

- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{
    
}

@end
