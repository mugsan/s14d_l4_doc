//
//  Transmitter.m
//  Bombomanu_client
//
//  Created by Magnus Björk on 31/10/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#import "Thread.h"
@interface Thread()
/**
 *  Thread object
 */
@property NSThread* thread;

@property BOOL running;
@end


@implementation Thread

/**
 *  Sets selector to run
 *
 *  @return self
 */
- (instancetype)init
{
    if (self = [super init]) {
        _thread = [[NSThread alloc]initWithTarget:self selector:@selector(loop) object:nil];
    }
    return self;
}
/**
 *  Starts thread and sets loop boolean.
 */
- (void)start
{
    _running = YES;
    [_thread start];
}
/**
 *  Loop this function while true
 */
- (void)loop
{
    while (_running) {
        [self run];
    }
}
/**
 *  stops loop and thread
 */
- (void)stop
{
    _running = NO;
}

- (void)run {}

@end
