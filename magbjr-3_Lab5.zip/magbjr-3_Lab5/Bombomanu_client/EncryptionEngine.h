//
//  encryptionEngine.h
//  TestingPlace
//
//  Created by Magnus Björk on 27/10/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#ifndef __TestingPlace__encryptionEngine__
#define __TestingPlace__encryptionEngine__

#include <stdio.h>

#include "PRGA.h"
class EncryptionEngine{
    PRGA* decryptPRGA;
    PRGA* encryptPRGA;
    
public:
    EncryptionEngine();
    ~EncryptionEngine();
    
    EncryptionEngine(const char* key, int keyLength);
    
    char* encrypt(char* txt, int len);
    char* decrypt(char* txt, int len);
    
};
#endif /* defined(__TestingPlace__encryptionEngine__) */
