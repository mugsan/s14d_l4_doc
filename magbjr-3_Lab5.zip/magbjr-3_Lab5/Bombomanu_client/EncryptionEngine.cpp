//
//  encryptionEngine.cpp
//  TestingPlace
//
//  Created by Magnus Björk on 27/10/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#include "EncryptionEngine.h"
EncryptionEngine::EncryptionEngine(const char* key, int keyLength){
    
    this->decryptPRGA = new PRGA(key, keyLength);
    this->encryptPRGA = new PRGA(key, keyLength);
}

EncryptionEngine::~EncryptionEngine(){
    delete this->decryptPRGA;
    delete this->encryptPRGA;
}

char* EncryptionEngine::encrypt(char* txt, int len){
    char* c = new char[len];
    for (int i = 0; i < len; ++i) {
        c[i] = txt[i] ^ this->encryptPRGA->getStream();
    }
    return c;
}

char* EncryptionEngine::decrypt(char* txt, int len){
    char* c = new char[len];
    for (int i = 0; i < len; ++i) {
        c[i] = txt[i] ^ this->decryptPRGA->getStream();
    }
    return c;
}