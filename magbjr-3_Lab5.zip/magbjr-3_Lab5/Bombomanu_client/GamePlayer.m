//
//  GamePlayer.m
//  Bombomanu_client
//
//  Created by Magnus Björk on 01/11/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#import "GamePlayer.h"

@interface GamePlayer()

@end

@implementation GamePlayer


- (instancetype)initWithName:(NSString*)name andColor:(UIColor*)color
{
    if (self = [super initWithImageNamed:@"bombomanu.png"]) {
        
        self.name = name;
        [self setColor:color];
        [self setColorBlendFactor:0.2];
    }
    return self;
}

@end
