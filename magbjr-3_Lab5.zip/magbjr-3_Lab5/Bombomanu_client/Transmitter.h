//
//  Transmitter.h
//  Bombomanu_client
//
//  Created by Magnus Björk on 31/10/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#import "Thread.h"
#import "Socket.h"

@interface Transmitter : Thread

- (instancetype)initWithSocket:(Socket*)socket;

@end
