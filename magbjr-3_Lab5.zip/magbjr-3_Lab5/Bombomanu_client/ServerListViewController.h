//
//  ServerListViewController.h
//  s0014d laboration5
//
//  Created by Magnus Björk on 15/10/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//
//  Lists added servers. Saves them to file.

#import <UIKit/UIKit.h>
#import "GameViewController.h"

@interface ServerListViewController : UITableViewController
- (IBAction)unwindToServerList:(UIStoryboardSegue*)unwindSegue;

- (void)saveList;

@end
