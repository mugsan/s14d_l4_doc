//
//  GamePlayer.h
//  Bombomanu_client
//
//  Created by Magnus Björk on 01/11/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface GamePlayer : SKSpriteNode
- (instancetype)initWithName:(NSString*)name andColor:(UIColor*)color;

@end
