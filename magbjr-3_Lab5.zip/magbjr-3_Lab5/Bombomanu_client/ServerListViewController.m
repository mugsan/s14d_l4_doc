//
//  ServerListViewController.m
//  s0014d laboration5
//
//  Created by Magnus Björk on 15/10/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#import "ServerListViewController.h"
#import "NewServerViewController.h"

@interface ServerListViewController() <UIAlertViewDelegate>
@property (weak, nonatomic) IBOutlet UIBarButtonItem *addButton;
@property (nonatomic) NSMutableArray *list;
@property (nonatomic) NSString* pathToFile;
@end

@implementation ServerListViewController
- (IBAction)clearButtonAction:(id)sender {
    UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"Warning!" message:@"This action will remove all saved serverdata!" delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:@"OK", nil];
    
    [alert show];
    
}

- (IBAction)unwindToServerList:(UIStoryboardSegue *)unwindSegue
{
    NewServerViewController* nsvc = [unwindSegue sourceViewController];
    
    if (nsvc.item) {
        [_list addObject:nsvc.item];
        [self saveList];
    }
}
- (IBAction)unwindToServerListFromGame:(UIStoryboardSegue *)unwindSegue
{
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    _pathToFile = [NSString stringWithFormat:@"%@/file.dat", documentsDirectory];
    _list = [self loadList];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(saveList) name:@"save" object:nil];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (NSMutableArray*)loadList
{
    NSMutableArray* array = [NSMutableArray arrayWithContentsOfFile:_pathToFile];
    return (array)? array : [NSMutableArray array];
}

- (void)saveList
{
    [_list writeToFile:_pathToFile atomically:YES];
}

#pragma mark - Table View Delegate

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:@"serverCell" forIndexPath:indexPath];
    NSMutableDictionary* listItem = [_list objectAtIndex:indexPath.row];
    cell.textLabel.text = listItem[@"name"];
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%@:%@",listItem[@"address"],listItem[@"port"]];
    
    return cell;
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if (sender != _addButton) {
        NSIndexPath* indexPath = [self.tableView indexPathForSelectedRow];
        GameViewController* target = (GameViewController*)[segue destinationViewController];
        target.serverProperties = _list[indexPath.row];
    }
    
    
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_list count];
}

#pragma mark - Alert View Delegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 1) {
        [_list removeAllObjects];
        [self saveList];
        [self.tableView reloadData];
    }
}
@end
