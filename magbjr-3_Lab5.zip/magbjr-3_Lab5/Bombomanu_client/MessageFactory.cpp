//
//  MessageFactory.cpp
//  Bombomanu_client
//
//  Created by Magnus Björk on 31/10/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#include "MessageFactory.h"

volatile unsigned int MessageFactory::seq_no = 0;

MessageFactory::MessageFactory(int id_no){
    this->id_no = id_no;
}

MsgHead MessageFactory::create_head(MsgType type, int size){
    MsgHead msg;
    
    msg.id     = this->id_no;
    msg.type   = type;
    msg.length = size;
    msg.seq_no = MessageFactory::seq_no++;
    
    return msg;
}

JoinMsg MessageFactory::create_join(){
    JoinMsg msg;
    
    msg.head = this->create_head(Join, sizeof msg);
    
    return msg;
}

LeaveMsg MessageFactory::create_leave(){
    LeaveMsg msg;
    
    msg.head = this->create_head(Leave, sizeof msg);
    
    return msg;
}

EventMsg MessageFactory::create_event(EventType type){
    EventMsg msg;
    
    msg.head = this->create_head(Event, sizeof msg);
    msg.type = type;
    
    return msg;
}

BombuMsg MessageFactory::create_bomb(Coordinate pos, int bomb_number){
    BombuMsg msg;
    
    msg.pos   = pos;
    msg.event = this->create_event(Bomb);
    msg.event.head.length = sizeof msg;
    
    return msg;
}

MoveMsg MessageFactory::create_move(MoveType type){
    MoveMsg msg;
    
    msg.type  = type;
    msg.event = create_event(Move);
    msg.event.head.length = sizeof msg;
    
    return msg;
}

DestinationMsg MessageFactory::create_destination(Coordinate pos){
    DestinationMsg msg;
    
    msg.pos     = pos;
    msg.msg = this->create_move(Destination);
    msg.msg.event.head.length = sizeof msg;
    
    return msg;
}

AdvanceMsg MessageFactory::create_advance(){
    AdvanceMsg msg;
    
    msg.msg = this->create_move(Advance);
    msg.msg.event.head.length = sizeof msg;
    
    return msg;
}

ChangeMsg MessageFactory::create_change(ChangeType type){
    ChangeMsg msg;
    
    msg.head = this->create_head(Change, sizeof(msg));
    msg.type = type;
    
    return msg;
}

NewPlayerMsg MessageFactory::create_new_player(Coordinate pos){
    NewPlayerMsg msg;
    
    msg.pos = pos;
    msg.msg = this->create_change(NewPlayer);
    msg.msg.head.length = sizeof msg;
    
    return msg;
}

NewPlayerMsg MessageFactory::create_new_player(Player player){
    NewPlayerMsg msg;
    
    msg.pos = player.pos;
    msg.msg = this->create_change(NewPlayer);
    msg.msg.head.length = sizeof msg;
    msg.msg.head.id = player.id;
    
    return msg;
}

NewPlayerPositionMsg MessageFactory::create_new_player_position(Coordinate pos){
    NewPlayerPositionMsg msg;
    
    msg.msg = this->create_change(NewPlayerPosition);
    msg.msg.head.length = sizeof msg;
    msg.pos = pos;
    
    return msg;
}

NewBombuPositionMsg MessageFactory::create_new_bomb_position(int bombid, Coordinate pos){
    NewBombuPositionMsg msg;
    
    msg.bombid = bombid;
    msg.pos = pos;
    msg.msg = this->create_change(NewBombPosition);
    msg.msg.head.length = sizeof msg;
    
    return msg;
}

ExplosionMsg MessageFactory::create_explosion(int bombid, int str){
    ExplosionMsg msg;
    
    msg.bombid = bombid;
    msg.str = str;
    msg.msg = this->create_change(Explosion);
    msg.msg.head.length = sizeof msg;
    
    return msg;
}

PlayerLeaveMsg MessageFactory::create_player_leave(){
    PlayerLeaveMsg msg;
    
    msg.msg = this->create_change(PlayerLeave);
    msg.msg.head.length = sizeof msg;
    
    return msg;
}

PlayerDiedMsg MessageFactory::create_player_died(int id){
    PlayerDiedMsg msg;
    
    msg.msg = this->create_change(PlayerDied);
    msg.msg.head.id = id;
    msg.msg.head.length = sizeof msg;
    
    return msg;
}

PlayerStopMsg MessageFactory::create_player_stop(){
    PlayerStopMsg msg;
    
    msg.msg = this->create_change(PlayerStop);
    msg.msg.head.length = sizeof msg;
    
    return msg;
}

PlayerWonMsg MessageFactory::create_player_won(int id){
    PlayerWonMsg msg;
    
    msg.msg = this->create_change(PlayerWon);
    msg.msg.head.length = sizeof msg;
    msg.msg.head.id = id;
    
    return msg;
}

























