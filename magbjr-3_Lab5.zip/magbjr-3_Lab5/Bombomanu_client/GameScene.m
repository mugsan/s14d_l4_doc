//
//  GameScene.m
//  Bombomanu_client
//
//  Created by Magnus Björk on 30/10/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#import "GameScene.h"
#import "GamePlayer.h"
#import "GameFinished.h"
#import "GameViewController.h"
#import "ThreadManager.h"

/**
 *  Used to control views and render them.
 */
@interface GameScene() <ThreadManagerDelegate>
/**
 *  Stores views added to the level
 */
@property (nonatomic) NSMutableDictionary* views;
/**
 *  Manages communication with server
 */
@property (nonatomic) ThreadManager* manager;
/**
 *  User input coordinate.
 */
@property (nonatomic) CGPoint input;
/**
 *  Scale of background after sizechange.
 */
@property (nonatomic) CGFloat scale;
/**
 *  The level wich the game plays on.
 */
@property (nonatomic) SKSpriteNode* level;
/**
 *  If the game is playing. Decides wether to take userinput or not.
 */
@property (nonatomic) BOOL playing;
/**
 *  Filepath to explosion .sks file
 */
@property (nonatomic) NSString* explosionPath;
@end

@implementation GameScene
@synthesize delegate;
/**
 *  Initiates some variables and starts the thread manager
 *  with url and port given from previous view
 */
-(void)didMoveToView:(SKView *)view {
    
    
    
    
    _explosionPath = [[NSBundle mainBundle] pathForResource:@"explosion" ofType:@"sks"];
    _views   = [NSMutableDictionary dictionary];
    _manager = [[ThreadManager alloc]initWithUrl:_serverProperties[@"address"] andPort:_serverProperties[@"port"]];
    _manager.delegate = self;
    
    CGSize s = [self frame].size;
    
    
    
    //Load level view.
    _level = [SKSpriteNode spriteNodeWithImageNamed:@"Level.png"];
    _scale = s.width / [_level frame].size.width;
    [_level setScale:_scale];
    CGPoint p = CGPointMake(([self frame].size.width / 2) - ([_level frame].size.width / 2), 0);
    _level.position = p;
    
    [self addChild:_level];
    [_level setAnchorPoint:CGPointZero];
    
    [_manager start];
    _playing = YES;
}
/**
 *  Used when disconnecting from the game.
 */
- (void)disconnect
{
    [_manager stop];
    UIViewController* gvc = (UIViewController*)[[[self view] window] rootViewController];
    [gvc dismissViewControllerAnimated:YES completion:nil];
}
/**
 *  Transforms touched coordinate so it conforms to the models.
 *
 *  @param touches
 *  @param event
 */
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    
    if (!_playing) return;
    
    for (UITouch *touch in touches) {
        CGPoint p = [touch locationInNode:_level];
        
        SKNode* node = [_level nodeAtPoint: p];
        if ([node.name isEqualToString:@"player"]) {
            CGPoint p2 = CGPointMake(floorf((p.x + 8) / 16), floorf((p.y + 8) / 16));
            [_manager setBomb:p2];
        }else{
            _input = [touch locationInNode:_level];
            _input.x = floorf((_input.x + 8) / 16);
            _input.y = floorf((_input.y + 8) / 16);
        }
    }
}
/**
 *  Tells the manager to send a destination message to the server
 *
 *  @param touches
 *  @param event
 */
-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    if (_playing) [_manager setDestination:_input];
}

#pragma mark - Thread Manager Delegate
/**
 *  Adds a player to the view dictionary.
 *
 *  @param manager manager who received the message
 *  @param id_no   id of the new player
 *  @param pos     position of the new player
 */
- (void)manager:(ThreadManager*) manager playerJoin:(int)id_no atPosition:(CGPoint)pos
{
    CGPoint p = CGPointMake(pos.x * 16, pos.y * 16);
    
    GamePlayer* node = [[GamePlayer alloc]initWithName:@"player" andColor:[UIColor redColor]];
    [node setAnchorPoint:CGPointMake(0.5, 0.5)];
    [node setPosition:p];
    _views[[NSNumber numberWithInt:id_no]] = node;
    [_level addChild:node];
}
/**
 *  Adds an oponent to the player on the view.
 *
 *  @param manager manager who received the message
 *  @param id_no   id of the new oponent
 *  @param pos     position of the new player
 */
- (void)manager:(ThreadManager *)manager oponentJoin:(int)id_no atPosition:(CGPoint)pos
{
    CGPoint p = CGPointMake(pos.x * 16, pos.y * 16);
    
    GamePlayer* node = [[GamePlayer alloc]initWithName:@"oponent" andColor:[UIColor blueColor]];
    [node setAnchorPoint:CGPointMake(0.5, 0.5)];
    [node setPosition:p];
    _views[[NSNumber numberWithInt:id_no]] = node;
    [_level addChild:node];
}
/**
 *  The player died(this client).
 *
 *  @param manager manager who received the message
 *  @param id_no   id number of the player
 */
- (void)manager:(ThreadManager*) manager playerDied:(int)id_no
{
    NSNumber* id_n = [NSNumber numberWithInt:id_no];
    SKSpriteNode* node = _views[id_n];
    [node removeFromParent];
    [_views removeObjectForKey:id_n];
    
    GameFinished* node2 = [[GameFinished alloc]initWithTitle:@"You lost!" andScene:self];
    [self addChild:node2];
    _playing = NO;
}
/**
 *  Oponent died(some other client)
 *
 *  @param manager manager who received the message
 *  @param id_no   id number of oponent
 */
- (void)manager:(ThreadManager*) manager oponentDied:(int)id_no
{
    NSNumber* id_n = [NSNumber numberWithInt:id_no];
    SKSpriteNode* node = _views[id_n];
    [node removeFromParent];
    [_views removeObjectForKey:id_n];
}

/**
 *  Player left, remove him from view
 *
 *  @param manager manager who received the message
 *  @param id_no   id of player
 */
- (void)manager:(ThreadManager*) manager playerLeft:(int)id_no
{
    NSNumber* id_n = [NSNumber numberWithInt:id_no];
    SKSpriteNode* node = _views[id_n];
    [node removeFromParent];
    [_views removeObjectForKey:id_n];
    
}

/**
 *  Player(or oponent) moved, animate the movement
 *
 *  @param manager manager who received the message
 *  @param id_no   id of player who moved
 *  @param pos     player moved to this position
 */
- (void)manager:(ThreadManager*) manager player:(int)id_no movedTo:(CGPoint)pos
{
    CGPoint p = CGPointMake(pos.x * 16, pos.y * 16);
    SKSpriteNode* node = _views[[NSNumber numberWithInt:id_no]];
    SKAction* move = [SKAction moveTo:p duration:0.3];
    [node runAction:move];
}
/**
 *  A bomb appeared at a position. Add it to views
 *
 *  @param manager manager who received the message
 *  @param pos     position of the bomb
 *  @param id      id of the bomb
 */
- (void)manager:(ThreadManager*) manager bombAt:(CGPoint)pos withId:(int)id
{
    NSLog(@"PLACED BOMBID: %d",id);
    CGPoint p = CGPointMake(pos.x * 16, pos.y * 16);
    
    SKSpriteNode* node = [SKSpriteNode spriteNodeWithImageNamed:@"nuke.png"];
    _views[[NSNumber numberWithInt:id]] = node;
    [node setAnchorPoint:CGPointMake(.5,.5)];
    [node setPosition:p];
    [_level addChild:node];
    
}

/**
 *  Called when manager receives an explosion message form the server.
 *
 *  @param manager manager who received the message.
 *  @param id      identity number of the bomb
 *  @param str     strength of the bomb
 */
- (void)manager:(ThreadManager *)manager explodeBombId:(int)id andStr:(int)str
{
    NSLog(@"bombid: %d",id);
    SKSpriteNode* node = _views[[NSNumber numberWithInt:id]];
    
    SKEmitterNode* explosion = [NSKeyedUnarchiver unarchiveObjectWithFile:_explosionPath];
    
    [explosion setPosition:[node position]];
    
    [node removeFromParent];
    [_views removeObjectForKey:[NSNumber numberWithInt:id]];
    [_level addChild:explosion];
    
    SKAction* fade = [SKAction fadeOutWithDuration:1];
    [explosion runAction:fade completion:^{[explosion removeFromParent];}];
}

/**
 *  Player won(this client=
 *
 *  @param manager manager who receieved the message
 *  @param id_no   id of player
 */
- (void)manager:(ThreadManager *)manager playerWon:(int)id_no
{
    GameFinished* node = [[GameFinished alloc]initWithTitle:@"You won!" andScene:self];
    [self addChild:node];
    _playing = NO;
}

@end
