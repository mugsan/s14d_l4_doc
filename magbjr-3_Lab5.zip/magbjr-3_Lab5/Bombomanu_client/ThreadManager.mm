//
//  ThreadManager.m
//  Bombomanu_client
//
//  Created by Magnus Björk on 30/10/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#import "ThreadManager.h"
#import "MessageFactory.h"
#import <math.h>

@interface ThreadManager() <ListenerDelegate>
/**
 *  Thread that listens for incoming traffic
 */
@property (nonatomic) Listener* listener;
/**
 *  Thread that sends messages to server.
 */
@property (nonatomic) Transmitter* transmitter;
/**
 *  Factory for createing message strucs.
 */
@property (nonatomic) MessageFactory* factory;
/**
 *  Id number of this client, given by server
 */
@property (nonatomic) int id_no;
/**
 *  Socket object to send and receive messages
 */
@property Socket* socket;
/**
 *  If the player is moving or has stopped.
 */
@property (nonatomic) BOOL moving;
@end

/**
 * Initiates threads and socket
 */
@implementation ThreadManager

- (instancetype)initWithUrl:(NSString *)url andPort:(NSString *)port
{
    if (self = [super init]) {
        
        _factory     = new MessageFactory(0);
        _socket      = [[Socket alloc] initWith:url andPort:port];
        _listener    = [[Listener alloc] initWithSocket:_socket];
        _listener.delegate = self;
        
        _transmitter = [[Transmitter alloc] initWithSocket:_socket];
        
    }
    return self;
}

/**
 *  Starts threads and send a join message to the server.
 */
- (void)start
{
    [_listener start];
    [_transmitter start];
    
    JoinMsg j = _factory->create_join();
    [_socket addMessageToBuffer:(char*)&j];
}

/**
 *  Sends a leave message to the server and stopts the threads.
 */
- (void)stop
{
    
    LeaveMsg l = _factory->create_leave();
    [_socket addMessageToBuffer:(char*)&l];
    
    [_listener stop];
    [_transmitter stop];
    
}
/**
 *  Sends a destination message to the server
 *
 *  @param pos destination of client
 */
- (void)setDestination:(CGPoint)pos
{
    Coordinate c;
    c.x = (int)pos.x;
    c.y = (int)pos.y;
    
    DestinationMsg msg = _factory->create_destination(c);
    [_socket addMessageToBuffer:(char*)&msg];
    
    if (!_moving) {
        
        AdvanceMsg msg2 = _factory->create_advance();
        [_socket addMessageToBuffer:(char*)&msg2];
        
    }
    
    _moving = YES;
}
/**
 *  Sends BombuMsg to server with position pos.
 *
 *  @param pos position of placed bomb
 */
- (void)setBomb:(CGPoint)pos
{
    Coordinate c;
    c.x = (int)pos.x;
    c.y = (int)pos.y;
    
    BombuMsg msg = _factory->create_bomb(c,3);
    [_socket addMessageToBuffer:(char*)&msg];
}
/**
 *  Send a movement request to server
 */
- (void)advanceMovement
{
    AdvanceMsg msg = _factory->create_advance();
    [_socket addMessageToBuffer:(char*)&msg];
}

#pragma mark - Listener Delegate
/**
 *  Called when client receives a message from the server
 *
 *  @param listener Listener thread that received the message
 *  @param message  begining of byte array of message
 *  @param length   length of said array
 */
- (void)listener:(Listener *)listener didReceiveMessage:(char *)message withLength:(int)length
{
    if (length <= 0) {
        [self stop];
        return;
    }
    unsigned int index = 0;
    printf("<-- [buffer of size: %d]\n",length);
    while (index < length) {
        
        MsgHead* m = (MsgHead*)&message[index];
        printf("\t[Msg->");
        index += m->length;
        
        switch (m->type) {
            case Join:{
                printf("Join]\n");
                printf("\t[id: %d length: %d]\n",m->id,m->length);
                JoinMsg* j = (JoinMsg*)m;
                _factory->id_no = j->head.id;
                _id_no = j->head.id;
                break;
            }
            case Change:{
                printf("Change->");
                ChangeMsg* c = (ChangeMsg*)m;
                switch (c->type) {
                    case NewPlayer:{
                        NewPlayerMsg *n = (NewPlayerMsg*)m;
                        printf("NewPlayer]\n");
                        printf("\t[id: %d length: %d]\n",m->id,m->length);
                        
                        CGPoint p = CGPointMake(n->pos.x, n->pos.y);
                        if (m->id == _id_no) {
                            [_delegate manager:self playerJoin:m->id atPosition:p];
                        }else{
                            [_delegate manager:self oponentJoin:m->id atPosition:p];
                        }
                        break;
                    }
                    case NewPlayerPosition:{
                        NewPlayerPositionMsg* n = (NewPlayerPositionMsg*)m;
                        CGPoint p = CGPointMake(n->pos.x, n->pos.y);
                        [_delegate manager:self player:m->id movedTo:p];
                        
                        if (_moving && m->id == _id_no) {
                            
                            AdvanceMsg msg = _factory->create_advance();
                            [_socket addMessageToBuffer:(char*)&msg];
                            
                        }
                        
                        printf("NewPlayerPosition]\n");
                        printf("\t[id: %d length: %d]\n",m->id,m->length);
                        printf("\t[pos.x: %d pos.y: %d]\n",n->pos.x,n->pos.y);
                        break;
                    }
                    case NewBombPosition:{
                        NewBombuPositionMsg* n = (NewBombuPositionMsg*)m;
                        CGPoint p;
                        p.x = n->pos.x;
                        p.y = n->pos.y;
                        [_delegate manager:self bombAt:p withId:n->bombid];
                        printf("NewBombPosition]\n");
                        printf("\t[bombid: %d]\n",n->bombid);
                        printf("\t[id: %d length: %d]\n",m->id,m->length);
                        printf("\t[pos.x: %d pos.y: %d]\n",n->pos.x,n->pos.y);
                        break;
                    }
                    case PlayerLeave:{
                        [_delegate manager:self playerLeft:m->id];
                        printf("PlayerLeave]\n");
                        printf("\t[id: %d length: %d]\n",m->id,m->length);
                        break;
                    }
                    case PlayerStop:{
                        _moving = NO;
                        printf("PlayerStop]\n");
                        printf("\t[id: %d length: %d]\n",m->id,m->length);
                        break;
                    }
                    case PlayerDied:{
                        if (m->id == _id_no) {
                            [_delegate manager:self playerDied:m->id];
                        }else{
                            [_delegate manager:self oponentDied:m->id];
                        }
                        
                        printf("PlayerDied]\n");
                        printf("\t[id: %d length: %d]\n",m->id,m->length);
                        break;
                    }
                    case PlayerWon: {
                        if (m->id == _id_no) {
                            [_delegate manager:self playerWon:m->id];
                        }
                        printf("PlayerWon]\n");
                        printf("\t[id: %d length: %d]\n",m->id,m->length);
                        break;
                    }
                    case Explosion:{
                        ExplosionMsg* e = (ExplosionMsg*)m;
                        printf("Explosion]\n");
                        printf("\t[id: %d length: %d]\n",m->id,m->length);
                        [_delegate manager:self explodeBombId: e->bombid andStr: e->str];
                        
                        break;
                    }
                    default:
                        break;
                }
                
                break;
            }
            default:
                break;
        }
    }
    printf("\n");
}

@end
