Fick problem att lägga upp presentationen på fronter så jag la upp den på Youtube istället. Den finns länkad i *.pdf men här är URL i alla fall: https://www.youtube.com/watch?v=ExhOKXWXvTQ
