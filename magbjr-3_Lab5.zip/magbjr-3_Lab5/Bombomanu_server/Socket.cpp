//
//  Socket.cpp
//  s0014d laboration5 server
//
//  Created by Magnus Björk on 20/10/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#include "Socket.h"
/**
 *  Initiates vars
 */
Socket::Socket(int sockfd){
    
    pthread_mutex_init(&this->lock, 0);
    this->encrypt = true; // turn true for encryption.
    this->sockfd = sockfd;
    this->buffer = new char[1024];
    this->encryptionEngine = new EncryptionEngine("key",3);
    this->bufferIndex = 0;
}
/**
 *  Receive message to given bytearray
 *
 *  @param buffer        begining of bytearray
 *  @param buffer_length length of bytearray
 *
 *  @return amount of bytes received -1 on error 0 on broken connection
 */
long Socket::receive(char* buffer, int buffer_length){
    long bytes = ::recv(this->sockfd, buffer, buffer_length,0);
    if (bytes > 0 && this->encrypt) {
        this->encryptionEngine->decrypt(buffer, (int)bytes);
    }
    return bytes;
}
/**
 *  Send given byte array.
 *
 *  @param msg begining of bytearray
 */
void Socket::send(char* msg){
    pthread_mutex_lock(&this->lock);
    
    MsgHead* m = (MsgHead*)msg;
    int length = m->length;
    printf("--> [%d bytes sent]\n",length);
    if (this->encrypt) this->encryptionEngine->encrypt(msg, length);
    ::send(this->sockfd, msg, length, 0);
    
    pthread_mutex_unlock(&this->lock);
}
/**
 *  Sends given bytearray of given length.
 *  Used if multiple messages are in the same array.
 *
 *  @param msg    begining of bytearray
 *  @param length length of array
 */
void Socket::send(char* msg, int length){
    printf("--> [%d bytes sent]\n",length);
    if (this->encrypt) this->encryptionEngine->encrypt(msg, length);
    ::send(this->sockfd, msg, length, 0);
}
/**
 *  Close socket
 */
void Socket::close(void){
    ::close(this->sockfd);
}
/**
 *  Append given bytearray to current bufferIndex
 *
 *  @param msg begining of bytearray
 */
void Socket::addMsgToBuffer(char* msg){
    pthread_mutex_lock(&this->lock);
    
    MsgHead* m = (MsgHead*)msg;
    printf("\t[length: %d]\n",m->length);
    ::memcpy(&this->buffer[bufferIndex], msg, m->length);
    this->bufferIndex += m->length;
    
    pthread_mutex_unlock(&this->lock);
}
/**
 *  Sends current buffer and resets index.
 */
void Socket::sendBuffer(){
    pthread_mutex_lock(&this->lock);
    
    if (this->encrypt) this->encryptionEngine->encrypt(this->buffer, this->bufferIndex);
    int bytes = (int)::send(this->sockfd, this->buffer, this->bufferIndex, 0);
    printf("--> [buffer sent: %d bytes]\n", bytes);
    
    this->bufferIndex = 0;
    
    pthread_mutex_unlock(&this->lock);
}
