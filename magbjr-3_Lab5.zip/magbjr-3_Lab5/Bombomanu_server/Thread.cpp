//
//  Thread.cpp
//  s0014d laboration5 server
//
//  Created by Magnus Björk on 20/10/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#include "Thread.h"
/**
 *  Entry point for pthread
 *
 *  @param a_thread Object who called the entry point
 *
 *  @return NULL
 */
void* Thread::run(void* a_thread){
    
    Thread* thread = (Thread*)a_thread;
    thread->action();
    return NULL;
}

/**
 *  Client thread on server, listens for incoming messages, validates them
 *  and modifies gamemodel if valid.
 *
 *  @param id_no unique identifier of client (socket file descriptor)
 *  @param socket the connection to this threads client.
 *  @param clients vector of all connections to the server.
 *  @param model game data.
 */
Thread::Thread(int id_no, Socket* socket, std::vector<Socket*>* clients, GameModel* model){
    
    this->playerAdded = false;
    this->model   = model;
    this->socket  = socket;
    this->clients = clients;
    this->id_no   = id_no;
    this->factory = new MessageFactory(id_no);
    
}

/**
 *  Starts thread by calling entry point.
 */
void Thread::start(){
    
    this->running = true;
    pthread_t p;
    pthread_create(&p, 0, &Thread::run, (void*)this);
}
/**
 *  Stops loop
 */
void Thread::stop(){
    this->running = false;
}


/**
 *  Called form entry point
 *  Receives messages in a loop
 *  If message is received process the message with processMsg method.
 *  If loop is broken remove socket and player form model, stop thread.
 */
void Thread::action(){
    std::cout << "Thread start.\n";
    char* buffer = new char[1024];
    long length;
    
    while (this->running){
        length = this->socket->receive(buffer, 1024);
        if (length < 1) {
            printf("Broken\n");
            this->running = false;
        }else{
            this->processMsg(buffer, length);
        }
    }
    
    
    printf("Removing socket.\n");
    //Remove socket.
    auto it = std::find(this->clients->begin(), this->clients->end(), this->socket);
    if (it != this->clients->end()) {
        this->clients->erase(it);
    }
    
    //Close socket.
    printf("Closing socket.\n");
    this->socket->close();
    
    if (this->playerAdded) {
        this->model->removePlayer(this->id_no);
        
        //Multicast PlayerLeaveMsg
        for(auto &it : *this->clients){
            PlayerLeaveMsg out = this->factory->create_player_leave();
            it->send((char*)&out);
        }
    }
    
    delete socket;
    delete buffer;
    printf("Thread dead.\n");
}

/**
 *  Receives one ore more messages, validates each message and 
 *  modifies model if valid. If change in model, relay message to clients
 *
 *  @param msg begingin of bytearray with message/s
 *  @param len total length of message/s
 */
void Thread::processMsg(char* msg, long len){
    
    long index = 0;//used to differentiate message from buffer
    while (index < len) {
        
        if (!this->validateHead(msg)) {
            this->stop();
            return;
        }
        
        std::cout << "<-- [Msg->";
      
        MsgHead* m = (MsgHead*)&msg[index];
        index += m->length;
        
        switch (m->type) {
                
            case Join:{
                printf("Join id: %d length: %d seq: %d]\n",m->id,m->length,m->seq_no);
                //Unicast id to client.
                JoinMsg out = this->factory->create_join();
                this->socket->addMsgToBuffer((char*)&out);
                
                //Unicast model to Client.
                std::vector<Player>* tmp = this->model->getPlayers();
                for (auto &it : *tmp){
                    NewPlayerMsg u_npm = this->factory->create_new_player(it);
                    this->socket->addMsgToBuffer((char*)&u_npm);
                }
                delete tmp;
                this->socket->sendBuffer();
                
                //Add player to model
                Coordinate p = this->model->addPlayer(this->id_no);
                this->playerAdded = true;
                
                //Multicast the new Client.
                
                for (auto &it : *this->clients){
                    NewPlayerMsg m_npm = this->factory->create_new_player(p);
                    it->send((char*)&m_npm);
                }
            
                break;
            }
                
            case Leave:{
                printf("Leave id: %d length: %d seq: %d]\n",m->id,m->length,m->seq_no);
                this->stop(); //stops the thread.
                break;
            }
                
            case Event:{
                std::cout << "Event->";
                EventMsg* e = (EventMsg*)m;
                switch (e->type) {
                    case Move:{
                        MoveMsg* mm = (MoveMsg*)m;
                        switch (mm->type) {
                            case Destination:{
                                
                                printf("Destination: id: %d len: %d]\n",m->id,m->length);
                                DestinationMsg* d = (DestinationMsg*)m;
                                printf("\t[Position: x: %d y: %d]\n",d->pos.x,d->pos.y);
                                this->model->setDestination(m->id, d->pos);
                                break;
                                
                            }
                            case Advance:{
                                
                                printf("Advance: id: %d len: %d]\n",m->id,m->length);
                                if (this->model->advancePlayer(m->id)) {
                                    
                                    Coordinate p = this->model->getPlayerPosition(m->id);
                                    for(auto &it : *this->clients){
                                        NewPlayerPositionMsg msg = factory->create_new_player_position(p);
                                        it->send((char*)&msg);
                                    }
                                }else{
                                    
                                    PlayerStopMsg msg = factory->create_player_stop();
                                    this->socket->send((char*)&msg);
                                    
                                }
                                break;
                            }
                            default:
                                break;
                        }
                        break;
                    }
                    case Bomb:{
                        printf("Bomb: id %d len: %d]\n",m->id,m->length);
                        BombuMsg* b = (BombuMsg*)m;
                        
                        int bombid = this->model->placeBomb(b->pos, m->id);
                        if (bombid) {
                            for(auto &it : *this->clients){
                                NewBombuPositionMsg msg = factory->create_new_bomb_position(bombid, b->pos);
                                it->send((char*)&msg);
                            }
                        }
                        break;
                    }
                    default:
                        break;
                }
                
            }
            default:
                break;
        }
    }
}

/**
 *  Validate incoming message to differentiate garbage form actual message
 *
 *  @param msg begining of bytearray
 *
 *  @return true if valid message
 */
bool Thread::validateHead(const char* msg){
    
    MsgHead* m = (MsgHead*)msg;
    printf("<-- [Msg Validating: id: %d len: %d]\n",m->id,m->length);
    bool a = m->id == 0 || m->id == this->id_no;
    bool b = 16 <= m->length && m->length <= 56;
    
    return a && b;
}
