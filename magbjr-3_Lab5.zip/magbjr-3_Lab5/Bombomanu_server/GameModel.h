//
//  GameModel.h
//  s0014d laboration5 server
//
//  Created by Magnus Björk on 20/10/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#ifndef __s0014d_laboration5_server__GameModel__
#define __s0014d_laboration5_server__GameModel__

#include <stdio.h>
#include <map>
#include <vector>
#include <pthread.h>
#include <iostream>
#include <string.h>

#include "MessageFactory.h"
#include "BombuModel.h"

class GameModel{
    pthread_mutex_t lock;
    
    bool gameRunning;
    
    std::map<int, Player> players;
    std::map<int, BombuModel*> bombs;
    
    MessageFactory* factory;
    
    int** player_array;
    int** bomb_array;
    
    int** clean_array();
    
    bool collision(int id, Coordinate pos);
    
    
public:
    GameModel(void);
    Coordinate addPlayer(int id_no);
    void removePlayer(int id_no);
    std::vector<Player>* getPlayers(void);
    int getPlayersOnline(void);
    
    int placeBomb(Coordinate pos, int id);
    std::vector<ExplosionMsg>*  updateBombs();
    std::vector<PlayerDiedMsg>* updatePlayers();
    
    
    int checkGameState();
    void reset_game();
    
    
    //Player movement
    void setDestination(int id_no, Coordinate pos);
    bool advancePlayer(int id_no);
    Coordinate getPlayerPosition(int id_no);
    
};

#endif /* defined(__s0014d_laboration5_server__GameModel__) */
