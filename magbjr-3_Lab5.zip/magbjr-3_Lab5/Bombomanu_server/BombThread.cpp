//
//  Thread.cpp
//  s0014d laboration5 server
//
//  Created by Magnus Björk on 20/10/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#include "BombThread.h"
/**
 *  Entry point of bombthread
 *
 *  @param a_thread Object that called the entry point
 *
 *  @return NULL
 */
void* BombThread::run(void* a_thread){
    
    BombThread* thread = (BombThread*)a_thread;
    thread->action();
    return NULL;
}

/**
 *  Used by server to update bombs and players and checks for winners of game
 * @param clients vector of connections to server
 * @param model datamodel of server
 */
BombThread::BombThread(std::vector<Socket*>* clients, GameModel* model){
    
    this->clients = clients;
    this->model = model;
    
}

/**
 *  Calls entry point and sets loop to true
 */
void BombThread::start(){
    
    this->running = true;
    pthread_t p;
    pthread_create(&p, 0, &BombThread::run, (void*)this);
    
}

/**
 *  stops loop and thread
 */
void BombThread::stop(){
    
    this->running = false;
    
}


/**
 *  updates timing of all bombs in model
 *  multicasts explosions to clients if any bomb exploded
 *  multicasts any players that died of explosions
 *  unicasts winner of game if any.
 */
void BombThread::action(){
    std::vector<ExplosionMsg>  *explosions;
    std::vector<PlayerDiedMsg> *deadGuys;
    while (this->running) {
        explosions = this->model->updateBombs();
        if (explosions != 0) {
            printf("\t[amount of explosions: %lu]\n",explosions->size());
            for (auto &it : *explosions) {
                printf("bombid: %d\n",it.bombid);
            }
            
            int emsg_size = sizeof(ExplosionMsg);
            char* c = new char[explosions->size() * emsg_size];
            int index = 0;
            
            for (auto &it : *explosions) {
                ::memcpy(&c[index], &it, emsg_size);
                index += emsg_size;
            }
            
            for (auto const &it : *this->clients) {
                it->send(c, index);
            }
            delete c;
            delete explosions;
        }
        deadGuys = this->model->updatePlayers();
        if (deadGuys != 0){
            printf("\t[amount of dead people: %ld]\n",deadGuys->size());
            int pdmsg_size = sizeof(PlayerDiedMsg);
            char* c = new char[deadGuys->size() * pdmsg_size];
            int index = 0;
            
            for (auto &it : *deadGuys){
                ::memcpy(&c[index], &it, pdmsg_size);
                index += pdmsg_size;
            }
            
            for (auto const &it : *this->clients){
                it->send(c, index);
            }
            delete c;
            delete deadGuys;
        }
        int playerWon = this->model->checkGameState();
        if (playerWon != 0) {
            
            printf("\t[player won: %d]\n",playerWon);
            for (auto &it : *this->clients) {
                PlayerWonMsg msg;
                msg.msg.type = PlayerWon;
                msg.msg.head.type = Change;
                msg.msg.head.length = sizeof msg;
                msg.msg.head.id = playerWon;
                
                it->send((char*)&msg);
            }
        }
        
        
        usleep(200000);
    }
}