//
//  main.cpp
//  s0014d laboration5 server
//
//  Created by Magnus Björk on 19/10/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#include <iostream>
#include "ServerSocket.h"
#include "Socket.h"
#include "MessageStructure.h"
#include "Thread.h"
#include "BombThread.h"
#include "BombuModel.h"

#include <sys/time.h>

int main(int argc, const char * argv[]) {
    std::cout << "server start...\n";
    //----start test
    
    //----end test
    
    GameModel * model = new GameModel();
    std::vector<Socket*>* clients = new std::vector<Socket*>();
    BombThread* bthread = new BombThread(clients, model);
    
    ServerSocket* ss = new ServerSocket("12345");
    bthread->start();
    int socketfd;
    while ((socketfd = ss->accept())) {
        std::cout << "accepted.\n";
        Socket* socket = new Socket(socketfd);
        clients->push_back(socket);
        Thread* thread = new Thread(socketfd, socket, clients, model);
        thread->start();
    }
    return 0;
}
