//
//  BombuModel.h
//  Bombomanu_client
//
//  Created by Magnus Björk on 03/11/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#ifndef __Bombomanu_client__BombuModel__
#define __Bombomanu_client__BombuModel__

#include <stdio.h>
#include <ctime>
#include <time.h>
#include <sys/time.h>
#include "MessageStructure.h"

class BombuModel{
    long lastTime;
    long timer;
    
public:
    int ownerid;
    int bombid;
    int str;
    Coordinate pos;
    bool isDetonated;
    
    BombuModel(int ownerid, int bombid, int str, Coordinate pos);
    bool update(void);
};

#endif /* defined(__Bombomanu_client__BombuModel__) */
