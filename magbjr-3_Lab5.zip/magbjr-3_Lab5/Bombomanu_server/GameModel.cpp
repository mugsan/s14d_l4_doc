//
//  GameModel.cpp
//  s0014d laboration5 server
//
//  Created by Magnus Björk on 20/10/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#include "GameModel.h"

# pragma mark - Private methods
/**
 *  Collision check, checks various entity arrays (players, bombs) to see if tile is occupied.
 *  Check players array of gamefield to see if player has been there before
 *
 *  @param id  id of player to move
 *  @param pos position player wants to move to
 *
 *  @return true if collision occurs
 */
bool GameModel::collision(int id, Coordinate pos){
    
    int player = this->player_array[pos.x][pos.y];
    int bomb   = this->bomb_array[pos.x][pos.y];
    int path   = this->players[id].path_array[pos.x][pos.y];
    
    printf("\t[player: %d bomb: %d path: %d]\n",player, bomb,path);
    return  (player + bomb) != 0 || path == 1;
}

/**
 *  resets player_array and bomb_array to default gamefield
 */
void GameModel::reset_game(){
    if (this->player_array) {
        for (int i = 0; i < 15; i++) {
            delete [] player_array[i];
            delete [] bomb_array[i];
        }
    }
    this->player_array = this->clean_array();
    this->bomb_array   = this->clean_array();
}

/**
 *  Creates a clean gamefield represented as an array of 1s and 0s
 *
 *  @return the new array
 */
int** GameModel::clean_array(){
    int rows = 9;
    int cols = 15;
    
    int* arr   = new int[rows * cols];
    int** arr2 = new int*[cols];
    
    for (int i = 0; i < cols; i++) {
        arr2[i] = &arr[i * rows];
        for (int j = 0; j < rows; j++) {
            int val = 0;
            if (i == 0 || j == 0 || j == rows - 1 || i == cols - 1 || (i % 2 == 0 && j % 2 == 0)) {
                val = 1;
            }
            arr2[i][j] = val;
        }
    }
    return arr2;
}

# pragma mark - Public methods


GameModel::GameModel(void){
    this->gameRunning = false;
    this->factory = new MessageFactory(0);
    this->players = std::map<int, Player>();
    
    if (pthread_mutex_init(&this->lock, 0) != 0) {
        std::cout << "Error initializing mutex.\n";
    }
    this->reset_game();
}
/**
 *  Checks if there is a winner of the game
 *
 *  @return true if there is a winner
 */
int GameModel::checkGameState(){
    int winner = 0;
    if (gameRunning && this->players.size() == 1) {
        printf("\t[someone one]\n");
        this->gameRunning = false;
        winner = this->players.begin()->second.id;
    }
    return winner;
}

# pragma mark - Bomb methods

//returns bombid if bomb is placed or 0;
/**
 *  Checks if player has bombs and if tile is appropriate to place a bomb on
 *
 *  @param pos position to place bomb on
 *  @param id  player identity number
 *
 *  @return 0 if no bomb, identity of bomb if a bomb is placed
 */
int GameModel::placeBomb(Coordinate pos, int id){
    pthread_mutex_lock(&this->lock);
    Player* p = &this->players[id];
    int* val = &this->bomb_array[pos.x][pos.y]; // check list of bombs
    if (*val != 0 || p->tot_bombs < 1) {
        pthread_mutex_unlock(&this->lock);
        return 0;
    }
    
    //bombid - unique id for each bomb.
    int bombid = id * 10 + p->cur_bombs;
    *val = bombid;
    p->tot_bombs--;
    p->cur_bombs = p->cur_bombs + 1 % 10;
    
    BombuModel* model = new BombuModel(id, bombid, p->str_bombs, pos);
    this->bombs[bombid] = model;
    pthread_mutex_unlock(&this->lock);
    return bombid;
}

/**
 *  Iterates through map of bombs to update the internal timer of each
 *
 *  @return vector of explosionMsg of bombs that exploded
 */
std::vector<ExplosionMsg>* GameModel::updateBombs(){
    pthread_mutex_lock(&this->lock);
    std::vector<ExplosionMsg> *explosions = 0;
    
    for (auto it = this->bombs.begin(); it != this->bombs.end();/*increment in loop*/) {
        if (it->second->update()) {
            if (!explosions) {
                explosions = new std::vector<ExplosionMsg>();
            }
            //there be dragons here....
            
            //Explosions
            int str = it->second->str;
            Coordinate p = it->second->pos; // bomb position
            
            //explode north
            
            for (int i = 0; i < str; i++) {
                int player = this->player_array[p.x][p.y + i];
                int bomb   =   this->bomb_array[p.x][p.y + i];
                
                if (player > 1) {
                    printf("heres a player #: %d\n",player);
                    this->players[player].isAlive = false;
                    
                }else if (bomb > 1){
                    
                    printf("heres a bomb: %d\n",bomb);
                    this->bombs[bomb]->isDetonated = true;
                    
                }else if (player == 1 || bomb == 1){
                    
                    break;
                    
                }
            }
            
            //explode south
            for (int i = 0; i < str; i++) {
                int player = this->player_array[p.x][p.y - i];
                int bomb   =   this->bomb_array[p.x][p.y - i];
                
                if (player > 1) {
                    printf("heres a player #: %d\n",player);
                    this->players[player].isAlive = false;
                    
                }else if (bomb > 1){
                    
                    printf("heres a bomb: %d\n",bomb);
                    this->bombs[bomb]->isDetonated = true;
                    
                }else if (player == 1 || bomb == 1){
                    
                    break;
                    
                }
            }
            
            //explode west
            for (int i = 0; i < str; i++) {
                int player = this->player_array[p.x - i][p.y];
                int bomb   =   this->bomb_array[p.x - i][p.y];
                
                if (player > 1) {
                    printf("heres a player #: %d\n",player);
                    this->players[player].isAlive = false;
                    
                }else if (bomb > 1){
                    
                    printf("heres a bomb: %d\n",bomb);
                    this->bombs[bomb]->isDetonated = true;
                    
                }else if (player == 1 || bomb == 1){
                    
                    break;
                    
                }
            }
            
            //explode east
            for (int i = 0; i < str; i++) {
                int player = this->player_array[p.x + i][p.y];
                int bomb   =   this->bomb_array[p.x + i][p.y];
                
                if (player > 1) {
                    printf("heres a player #: %d\n",player);
                    this->players[player].isAlive = false;
                    
                }else if (bomb > 1){
                    
                    printf("heres a bomb: %d\n",bomb);
                    this->bombs[bomb]->isDetonated = true;
                    
                }else if (player == 1 || bomb == 1){
                    
                    break;
                    
                }
            }
            //add explosion message to return vector
            ExplosionMsg e = this->factory->create_explosion(it->second->bombid, it->second->str);
            explosions->push_back(e);
            
            //add bomb to player.
            Player* player = &this->players[it->second->ownerid];
            player->tot_bombs++;
            
            
            //remove bomb from bombs and entities
            this->bomb_array[p.x][p.y] = 0;
            this->bombs.erase(it++);
        }else{
            it++;
        }
    }
    pthread_mutex_unlock(&this->lock);
    return explosions;
}



# pragma mark - Player methods
/**
 *  Gets Players connected to server
 *
 *  @return vector of Player structs
 */
std::vector<Player>* GameModel::getPlayers(void){
    pthread_mutex_lock(&this->lock);
    
    std::vector<Player>* tmp = new std::vector<Player>();
    for (auto &it: this->players) {
        tmp->push_back(it.second);
    }
    
    pthread_mutex_unlock(&this->lock);
    return tmp;
}
/**
 *  Amount of players online
 *
 *  @return Amount of players online
 */
int GameModel::getPlayersOnline(){
    return (int)this->players.size();
}

/**
 *  Iterates through map of players to see if they are alive.
 *
 *  @return vetor of PlayerDiedMsg of players who died
 */
std::vector<PlayerDiedMsg>* GameModel::updatePlayers(){
    pthread_mutex_lock(&this->lock);
    std::vector<PlayerDiedMsg>* deadGuys = 0;
    for (auto it = this->players.begin(); it != this->players.end(); /* no increment */) {
        if (!it->second.isAlive) {
            if (deadGuys == 0) {
                deadGuys = new std::vector<PlayerDiedMsg>();
            }
            
            PlayerDiedMsg msg = this->factory->create_player_died(it->second.id);
            deadGuys->push_back(msg);
        
            this->player_array[it->second.pos.x][it->second.pos.y] = 0;
            this->players.erase(it++);
            
        }else{
            it++;
        }
    }
    
    pthread_mutex_unlock(&this->lock);
    return deadGuys;
}
/**
 *  Creates a new player struct with given id number
 *
 *  @param id_no id of the client connected
 *
 *  @return the coordinate where the new player appeared
 */
Coordinate GameModel::addPlayer(int id_no){
    pthread_mutex_lock(&this->lock);
    Player p;
    memset(&p, 0, sizeof p);
    
    p.id = id_no;
    p.isAlive = true;
    p.tot_bombs = 4;
    p.cur_bombs = 4;
    p.str_bombs = 4;
    p.path_array = this->clean_array();
    
    this->players[id_no] = p;
    struct Coordinate pos;
    pos.x = 1;
    pos.y = 1;
    
    while (this->collision(id_no, pos)) {
        pos.x++;
    }
    
    p.pos = pos;
    this->player_array[pos.x][pos.y] = p.id;
    
    this->players[id_no] = p;
    
    if (this->players.size() >= 2) this->gameRunning = true;
    
    pthread_mutex_unlock(&this->lock);
    return pos;
}
/**
 *  Remove given player with given id from model
 *
 *  @param id_no id of player to remove
 */
void GameModel::removePlayer(int id_no){
    pthread_mutex_lock(&this->lock);
    
    Player p = this->players[id_no];
    this->player_array[p.pos.x][p.pos.y] = 0;
    this->players.erase(this->players.find(id_no));
    
    pthread_mutex_unlock(&this->lock);
}

#pragma mark - Player movement
/**
 *  Advance player with given id towards its destination
 *
 *  @param id_no identity of player
 *
 *  @return true if player moved, false if player is stuck, has arrived
 */
bool GameModel::advancePlayer(int id_no){
    pthread_mutex_lock(&this->lock);
    
    Player*  player = &this->players[id_no];
    Coordinate  old = player->pos;
    Coordinate* pos = &player->pos;
    
    
    Coordinate dir;
    dir.x = player->destination.x - player->pos.x;
    dir.y = player->destination.y - player->pos.y;
    
    //basecase: player arrived to position.
    if (abs(dir.x) + abs(dir.y) == 0){
        pthread_mutex_unlock(&this->lock);
        return false;
    }
    
    Coordinate north;
    north.x = old.x;
    north.y = old.y + 1;
    
    Coordinate south;
    south.x = old.x;
    south.y = old.y - 1;
    
    Coordinate east;
    east.x = old.x + 1;
    east.y = old.y;
    
    Coordinate west;
    west.x = old.x - 1;
    west.y = old.y;
    
    //base priority of directions: 0: most important
    Coordinate directions[4] = {north, west, south, east};
    
    //set priority of directions in relation to distance (x/y)
    if (dir.y < 0) std::swap(directions[0], directions[2]);
    if (dir.x > 0) std::swap(directions[1], directions[3]);
    if (abs(dir.x) > abs(dir.y)) {
        std::swap(directions[0], directions[1]);
    }else{
        std::swap(directions[2], directions[3]);
    }
    
    
    
    for (int i = 0; i < 4; i++) {
        if (!this->collision(id_no, directions[i])) {
            
            this->player_array[old.x][old.y] = 0;       //unmark position as not-blocked.
            player->path_array[old.x][old.y] = 1;       //  mark position as visited.
            
            *pos = directions[i];                       //reference to players position.
            
            this->player_array[pos->x][pos->y] = id_no; //mark new position as blocked.
            pthread_mutex_unlock(&this->lock);
            return true;
        }
    }
    
    //player is stuck.
    pthread_mutex_unlock(&this->lock);
    return false;
}
/**
 *  Sets the destination of player of given identity
 *
 *  @param id_no identity of player
 *  @param pos   coordinate of new destination
 */
void GameModel::setDestination(int id_no, Coordinate pos){
    pthread_mutex_lock(&this->lock);
    
    Player* player = &this->players[id_no];
    player->destination = pos;
    player->path_array = this->clean_array();
    player->path_array[pos.x][pos.y] = 2;
    
    pthread_mutex_unlock(&this->lock);
}

/**
 *  Get position of player
 *
 *  @param id_no identity of player
 *
 *  @return Coordinate of players position
 */
Coordinate GameModel::getPlayerPosition(int id_no){
    return this->players[id_no].pos;
}
