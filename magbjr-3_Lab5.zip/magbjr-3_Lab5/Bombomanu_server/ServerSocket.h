//
//  ServerSocket.h
//  s0014d laboration5 server
//
//  Created by Magnus Björk on 19/10/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#ifndef __s0014d_laboration5_server__ServerSocket__
#define __s0014d_laboration5_server__ServerSocket__

#include "Socket.h"
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <iostream>
#include <string.h>

class ServerSocket{
    const char* port;
    int sockfd;
    
public:
    ServerSocket(const char* port);
    int accept();
    void close();
};

#endif /* defined(__s0014d_laboration5_server__ServerSocket__) */
