//
//  Socket.h
//  s0014d laboration5 server
//
//  Created by Magnus Björk on 20/10/14.
//  Copyright (c) 2014 Magnus Björk. All rights reserved.
//

#ifndef __s0014d_laboration5_server__Socket__
#define __s0014d_laboration5_server__Socket__

#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <iostream>
#include <unistd.h>
#include <vector>
#include <string.h>
#include <pthread.h>

#include "Socket.h"
#include "MessageFactory.h"
#include "EncryptionEngine.h"

class Socket{
    int sockfd;
    bool encrypt;
    pthread_mutex_t lock;
    EncryptionEngine* encryptionEngine;
    
    char* buffer;
    int bufferIndex;
    
public:
    Socket(int sockfd);
    
    long receive(char* buffer, int buffer_length);
    
    void send(char* msg);
    void send(char* msg, int length);
    void close(void);
    
    void addMsgToBuffer(char* msg);
    void sendBuffer();
    int sendVector(std::vector<ExplosionMsg> *vector);
};
#endif /* defined(__s0014d_laboration5_server__Socket__) */
